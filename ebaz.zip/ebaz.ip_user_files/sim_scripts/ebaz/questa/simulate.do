onbreak {quit -f}
onerror {quit -f}

vsim -t 1ps -lib xil_defaultlib ebaz_opt

do {wave.do}

view wave
view structure
view signals

do {ebaz.udo}

run -all

quit -force
